(function () {
    "use strict";
    function initController($scope) {
        var vm = this;
    }
    initController.$inject = ["$scope"];
    angular.module("fpm").controller("create-workorder-controller", initController);
})();