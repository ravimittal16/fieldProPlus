(function () {
    "use strict";
    function initController($scope) { }

    initController.$inject = ["$scope"];
    angular.module("fpm").controller("map-controller", initController);
})();